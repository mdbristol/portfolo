/**
Michael Bristol

Driver class

This class will act as the main method and will start the GUI by calling the main loop method.
*/

public class GameDriver
{
public static void main(String argv[])
 {
		GameGUI g = new GameGUI();
		
		g.gameLoop();
}
}

