/** 
 Created by Michael Bristol
 3/1/2010

 Driver class

 The main function is to to start the program by calling the GUI diplay method
*/



public class DriverHangman 
{
	  public static void main (String[] args)
		    {
				    Hangman sample = new Hangman();
					    sample.display();
						  }
}

