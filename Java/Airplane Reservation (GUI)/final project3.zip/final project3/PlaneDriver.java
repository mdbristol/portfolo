/** 

Michael Bristol
Plane Driver


The planeDriver will call the PlaneGUI that will start the program

*/

public class PlaneDriver
{


	public static void main(String[] args)
	{
	PlaneGUI plane = new PlaneGUI();
	plane.display();
	}
}
