/** 
 *
 * Michael Bristol
 * 2/3/10
 *
 * Driver class 
 *The Driver class only does a few things where it has a main method which calls a method that will start the program

 */

public class joeDriver
{
	public static void main(String[] args)
	{
		Menu menu = new Menu();//declares the object
		menu.displayMenu();//calls the first thing to run
	}
}
