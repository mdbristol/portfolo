/** Michael Bristol

mybutton class

*/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.IOException;

public class mybutton extends JButton
{
private int row;
private int column;


	public mybutton(int row_, int col)
	{
	row= row_;
	column=col;
	}

	public int getRow()
	{
	return row;
	}

	public int getCol()
	{
	return column;
	}
	public String toString()
	{
		String result= row + "," + column;
		return result;
	}
}
