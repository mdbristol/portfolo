/** 

Michael Bristol
Plane Driver


*/

public class PlaneDriver
{


	public static void main(String[] args)
	{
	PlaneGUI plane = new PlaneGUI();
	plane.display();
	}
}
