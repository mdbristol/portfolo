/** 

Michael Bristol
Cipher 


The Driver will call the CipherGUI that will start the program

*/

public class cipherDriver
{


	public static void main(String[] args)
	{
	CipherGUI code = new CipherGUI();
	code.display();
	}
}
